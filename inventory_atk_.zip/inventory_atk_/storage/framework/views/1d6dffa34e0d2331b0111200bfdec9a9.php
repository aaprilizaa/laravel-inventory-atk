<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barang Masuk | Stock ATK</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 flex min-h-screen text-slate-800">

    <aside class="w-64 bg-white border-r border-slate-200 hidden md:block">
        <div class="p-6">
            <div class="flex items-center gap-2 font-bold text-xl text-blue-600">
                <span>📦</span> Stock ATK.
            </div>
        </div>
        <nav class="px-4 space-y-1">
            <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center gap-3 px-4 py-3 text-slate-600 hover:bg-slate-100 rounded-xl transition">
                📊 Dashboard
            </a>
            
            <a href="<?php echo e(route('barang.index')); ?>" class="flex items-center gap-3 px-4 py-3 text-slate-600 hover:bg-slate-100 rounded-xl transition">
                📦 Data Barang
            </a>

            <?php if(auth()->user()->role == 'admin'): ?>
            <a href="<?php echo e(route('barang_masuk.index')); ?>" class="flex items-center gap-3 px-4 py-3 bg-blue-50 text-blue-600 rounded-xl font-semibold">
                📥 Barang Masuk
            </a>
            <?php endif; ?>

            <a href="<?php echo e(route('barang_keluar.index')); ?>" class="flex items-center gap-3 px-4 py-3 text-slate-600 hover:bg-slate-100 rounded-xl transition">
                📤 Barang Keluar
            </a>

            <div class="pt-10">
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="flex items-center gap-3 px-4 py-3 w-full text-red-500 hover:bg-red-50 rounded-xl transition font-medium">
                        🚪 Keluar Aplikasi
                    </button>
                </form>
            </div>
        </nav>
    </aside>

    <main class="flex-1 p-8">
        <header class="flex justify-between items-center mb-10">
            <div>
                <h1 class="text-2xl font-bold text-slate-800">Barang Masuk</h1>
                <p class="text-slate-500 text-sm">Catat penambahan stok barang yang masuk ke gudang.</p>
            </div>
            <div class="bg-white px-4 py-2 rounded-lg shadow-sm border border-slate-200 text-sm font-medium">
                📅 <?php echo e(date('d M Y')); ?>

            </div>
        </header>

        
        <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 mb-8">
            <h3 class="font-bold mb-4 text-slate-700 flex items-center gap-2">
                <span>📥</span> Form Input Stok Baru
            </h3>
            <form action="<?php echo e(route('barang_masuk.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div class="space-y-1">
                        <label class="text-xs font-semibold text-slate-500 uppercase">Pilih Barang</label>
                        <select name="barang_id" class="w-full border border-slate-200 p-2.5 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition bg-slate-50" required>
                            <option value="">-- Pilih Barang --</option>
                            <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($b->id); ?>"><?php echo e($b->nama); ?> (Stok: <?php echo e($b->stok); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="space-y-1">
                        <label class="text-xs font-semibold text-slate-500 uppercase">Jumlah Masuk</label>
                        <input type="number" name="jumlah" placeholder="Contoh: 50" class="w-full border border-slate-200 p-2.5 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition" required>
                    </div>

                    <div class="space-y-1">
                        <label class="text-xs font-semibold text-slate-500 uppercase">Tanggal Masuk</label>
                        <input type="date" name="tanggal" value="<?php echo e(date('Y-m-d')); ?>" class="w-full border border-slate-200 p-2.5 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition bg-slate-50" required>
                    </div>
                </div>

                <button type="submit" class="mt-6 px-8 py-2.5 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-200 transition">
                    💾 Simpan Stok Masuk
                </button>
            </form>
        </div>

        
        <div class="bg-white rounded-2xl shadow-sm overflow-hidden border border-slate-200">
            <div class="p-6 border-b border-slate-100 bg-slate-50/50">
                <h4 class="font-bold text-slate-700">Riwayat Barang Masuk</h4>
            </div>
            <table class="w-full text-left">
                <thead class="bg-slate-50 border-b border-slate-200">
                    <tr>
                        <th class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Nama Barang</th>
                        <th class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Jumlah</th>
                        <th class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Tanggal</th>
                        <th class="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Waktu Input</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-slate-50/50 transition">
                        <td class="px-6 py-4">
                            <div class="flex flex-col">
                                <span class="font-bold text-slate-700"><?php echo e($d->barang->nama); ?></span>
                                <span class="text-xs text-slate-400">Kode: <?php echo e($d->barang->kode); ?></span>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <span class="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-bold">
                                +<?php echo e($d->jumlah); ?>

                            </span>
                        </td>
                        <td class="px-6 py-4 text-slate-600 font-medium">
                            <?php echo e(\Carbon\Carbon::parse($d->tanggal)->format('d M Y')); ?>

                        </td>
                        <td class="px-6 py-4 text-slate-400 text-sm italic">
                            <?php echo e($d->created_at->diffForHumans()); ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="px-6 py-10 text-center text-slate-400 italic">
                            Belum ada riwayat transaksi barang masuk.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

    <script>
        // SweetAlert Notifikasi
        <?php if(session('success')): ?>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: "<?php echo e(session('success')); ?>",
                timer: 2500,
                showConfirmButton: false,
                customClass: { popup: 'rounded-3xl' }
            });
        <?php endif; ?>

        <?php if(session('error')): ?>
            Swal.fire({
                icon: 'error',
                title: 'Gagal!',
                text: "<?php echo e(session('error')); ?>",
                timer: 2500,
                showConfirmButton: false,
                customClass: { popup: 'rounded-3xl' }
            });
        <?php endif; ?>
    </script>

</body>
</html><?php /**PATH /Users/adiss/mystock/resources/views/barang_masuk/index.blade.php ENDPATH**/ ?>